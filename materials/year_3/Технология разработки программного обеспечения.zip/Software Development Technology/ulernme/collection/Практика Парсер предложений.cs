namespace TextAnalysis;

public class Params
{
	public char[] SliceContentData = {'.', '!', '?', ';', ':', '(', ')'};
}

static class SentencesParserTask
{
    public static List<List<string>> ParseSentences(string text)
	{
		Params p = new Params();
		if (string.IsNullOrEmpty(text)) return new List<List<string>>(); 
		var sensetivelist = new List<List<string>>();

		string[] sentences = ReplaceStroke(text,p.SliceContentData);
			
		foreach (var sentence in sentences)
		{
			var words = ParseWords(sentence);
			if (words.Count > 0) sensetivelist.Add(words);
		}
		return sensetivelist;
	}

	public static string[] ReplaceStroke(string text, char[] SliceContentData) 
		=> text.Split(SliceContentData,StringSplitOptions.RemoveEmptyEntries);
	
	public static List<String> ParseWords(string sentence)
	{
		var words = new List<String>();
		var currentWord = "";

		foreach(char c in sentence)
		{
			if (char.IsLetter(c) || c == '\'') 
					 currentWord += char.ToLower(c);
			else if (currentWord != "") 
			{
				words.Add(currentWord);
				currentWord = "";
			}
		}
		if (currentWord != "") words.Add(currentWord);
		return words;
	}
}