using System.Collections.Generic;
using Avalonia.Media;
using Geometry;

namespace GeometryPainting;

public static class GeometryPainting
{
	public static Dictionary<Segment, Color> SegmentColor 
		= new Dictionary<Segment, Color>();

	public static Color GetColor(this Segment segment)
		=> SegmentColor.ContainsKey(segment) ? SegmentColor[segment] : Colors.Black;
	
	public static void SetColor(this Segment segment, Color color)
		=> SegmentColor[segment] = color;
}