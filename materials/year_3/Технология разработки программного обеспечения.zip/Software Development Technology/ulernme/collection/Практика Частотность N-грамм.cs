static class FrequencyAnalysisTask
{
	public static Dictionary<string, string>
		GetMostFrequentNextWords(List<List<string>> text)
    {
		var result = new Dictionary<string, string>();
		var BiGramm = new Dictionary<string, Dictionary<string,int>>();
		var TriGramm = new Dictionary<string, Dictionary<string,int>>();

		foreach(var word in text)
		{
			for (int i = 0; i < word.Count; i++)
			{
				if (i + 1 < word.Count) 
					AddToFrequent(BiGramm,word[i],word[i+1]);
				if (i + 2 < word.Count) 
					AddToFrequent(TriGramm,word[i] + " " + word[i+1],word[i+2]);
			}
		}
		PreRender(BiGramm,result);
		PreRender(TriGramm,result);
        return result;
	}

	public static void AddToFrequent(Dictionary<string, Dictionary<string,int>> dictionary, string key,string nextWord)
	{
		if (!dictionary.ContainsKey(key)) 
			dictionary[key] = new Dictionary<string,int>();
		if (!dictionary[key].ContainsKey(nextWord)) 
			dictionary[key][nextWord] = 0; 
		dictionary[key][nextWord] ++;
	}

	public static string GetMaxFrequentNextWords(Dictionary<string,int> nextWord)
	{
		if (nextWord == null || nextWord.Count == 0) return string.Empty;
		int max = nextWord.Values.Max();
		string bestWord = null;

		var variants = new List<string>();
		foreach(var pair in nextWord)
		{
			if (pair.Value  == max)
			{
				if (bestWord == null || string.CompareOrdinal(pair.Key,bestWord) < 0)
					bestWord = pair.Key;
			}
		}
		return bestWord;
	}
	
	public static void PreRender(Dictionary<string, Dictionary<string,int>> NGramm, Dictionary<string, string> result)
	{
		foreach (var pair in NGramm) 
		{
			result[pair.Key] = GetMaxFrequentNextWords(pair.Value);
		}
	}
}