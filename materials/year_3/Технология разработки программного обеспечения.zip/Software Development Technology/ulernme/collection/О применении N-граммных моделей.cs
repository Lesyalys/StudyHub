namespace TextAnalysis;

public static class NGramHelper
{
	public static string? PredictedWord;
	public static bool IsInputValid(string phraseBeginning,int wordsCount) 
		=> !string.IsNullOrEmpty(phraseBeginning) && wordsCount >= 0;

	public static bool TryGetContainer
		(Dictionary<string, string> nextWords,
		List<string> currentWords,
		out string? predictedWord)
	{
		predictedWord = null;

		switch (currentWords.Count)
		{
			case 0: return false;
			case 1:
				string unigramKey = currentWords[currentWords.Count - 1];	
				return nextWords.TryGetValue(unigramKey,out predictedWord);
			default:
				string bigramKey 
					= currentWords[currentWords.Count - 2] 				
					+ " " + currentWords[currentWords.Count - 1];
				if (nextWords.TryGetValue(bigramKey, out predictedWord)) return true;
				goto case 1;
		}
	}
}

static class TextGeneratorTask
{
    public static string ContinuePhrase(
        Dictionary<string, string> nextWords,
        string phraseBeginning,
        int wordsCount)
	{
		if (!(NGramHelper.IsInputValid(phraseBeginning,wordsCount))) return phraseBeginning;

		var currentWords = new List<string>(phraseBeginning.Split(' '));	
		for (int i = 0; i < wordsCount; i++)
		{
			if (NGramHelper.TryGetContainer(
					nextWords,
					currentWords, 
					out string? PredictedWord)
			)
			{
				currentWords.Add(PredictedWord);
			} else break;
		}
        return string.Join(" ",currentWords);
    }
}