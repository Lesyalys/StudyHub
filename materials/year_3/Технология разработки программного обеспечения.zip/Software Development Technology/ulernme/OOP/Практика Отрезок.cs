namespace Geometry;

public class Segment
{
	public Vector Begin;
	public Vector End;
	
	public Segment()
	{
		Begin = new Vector(0,0);
		End   = new Vector(0,0);
	}
		
	public Segment(Vector begin,Vector end)
	{
		Begin = begin;
		End   = end;
	}

	public double GetDx() => End.X - Begin.X;
	public double GetDy() => End.Y - Begin.Y;
}

public class Vector
{
	public double X;
	public double Y;
	
	public Vector()
	{
		X = 0;
		Y = 0;
	}

	public Vector(double x, double y)
	{
		X = x;
		Y = y;
	}
}

public class Geometry
{
	public static double GetLength(Vector vector) 
		=> Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y);
		
	public static Vector Add(Vector vector1,Vector vector2) 
		=> new Vector(vector1.X + vector2.X, vector1.Y + vector2.Y);
	
	public static double GetLength(Segment segment)
		=> Math.Sqrt(segment.GetDx() * segment.GetDx() + segment.GetDy() * segment.GetDy());

	public static bool IsVectorInSegment(Vector vector, Segment segment) 
	{
		double dx = segment.End.X - segment.Begin.X;
		double dy = segment.End.Y - segment.Begin.Y;
		
		double crossProducts = (vector.X - segment.Begin.X) * dy -
							   (vector.Y - segment.Begin.Y) * dx;
		
		if (Math.Abs(crossProducts) > 1e-10) return false;

		double dotProduct = (vector.X - segment.Begin.X) * dx +
							(vector.Y - segment.Begin.Y) * dy;

		double sqrLength = dx * dx + dy * dy;
		
		if (sqrLength == 0)
		{
			return vector.X == segment.Begin.X && vector.Y == segment.Begin.Y;	
		}
		return dotProduct >=0 && dotProduct <= sqrLength;
	}
}