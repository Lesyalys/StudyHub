  [TestCase("I", new[] {"I"})]
			[TestCase("HATE HATE", new[] {"HATE", "HATE"})]
			[TestCase("WRITE'WRITE", new[] {"WRITE", "WRITE"})]
			[TestCase("TEST TEST    TEST", new[] {"TEST", "TEST", "TEST"})]
			[TestCase("\"FOR \\\"FOR\\\"\"", new[] {"FOR \"FOR\""})]
			[TestCase("\"THIS 'THIS' 'THIS' THIS\"", new[] {"THIS 'THIS' 'THIS' THIS"})]
			[TestCase("'\"EXPL\" \"EXPL\" \"EXPL\"'", new[] {"\"EXPL\" \"EXPL\" \"EXPL\""})]
			[TestCase("\"HELP\" HELP", new[] {"HELP","HELP"})]
			[TestCase("\"ME \\\\ ME\"",  new[] {"ME \\ ME"})]
			[TestCase("'A \\'A\\''",  new[] {"A 'A'"})]
			[TestCase("\"A ",  new[] {"A "})]
			[TestCase("\"A\\\\\"",  new[] {"A\\"})]
			[TestCase("   ", new string[0])]
			[TestCase("\"\"", new[] {""})]

            public static void RunTests(string input, string[] expectedOutput)
            {
            	Test(input, expectedOutput);
            }